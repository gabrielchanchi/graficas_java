package man;

import est.Estudiante;
import java.util.Vector;

public class Manejador {
    
    Vector estudiantes=new Vector(); 
    
    public void agregarEstudiante(String nombre, double nota, int edad){
         Estudiante e=new Estudiante(); 
         e.setNombre(nombre);
         e.setEdad(edad);
         e.setNota(nota);
         estudiantes.add(e);
    }
    public String listar(){
        Estudiante temp; 
        String cad="";
        for (int i = 0; i < estudiantes.size(); i++) {
            temp=(Estudiante)estudiantes.get(i);
            cad=cad+"============\n";
            cad=cad+"Nombre: "+temp.getNombre()+"\n";
            cad=cad+"Edad: "+temp.getEdad()+"\n";
            cad=cad+"Nota: "+temp.getNota()+"\n";
            cad=cad+"============\n";
        }
        return cad; 
    }
    public Vector calculo(){
        Estudiante temp; 
        int cont1=0; 
        int cont2=0; 
        int cont3=0;
        for (int i = 0; i < estudiantes.size(); i++) {
            temp=(Estudiante)estudiantes.get(i);
            if((double)temp.getNota()>=3.0){
                cont1++; 
            }
            else if((double)temp.getNota()>=2.0){
                cont2++; 
            }
            else{
                cont3++; 
            }
        }
        Vector datos=new Vector(); 
        datos.add(cont1);
        datos.add(cont2);
        datos.add(cont3);
        return datos;         
    }
    
    
    
}
