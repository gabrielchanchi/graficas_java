package grafica;

import java.util.Vector;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class Torta {
    Vector datos; 
    
    public void fijarDatos(Vector datos){
        this.datos=datos; 
    }
    public PieDataset crearDataSet(){
      DefaultPieDataset dataset = new DefaultPieDataset( );
      dataset.setValue( "Ganan" , new Integer( (int) datos.get(0)) );  
      dataset.setValue( "Habilitan" , new Integer( (int) datos.get(1)) );   
      dataset.setValue( "Pierden" , new Integer( (int) datos.get(2)) );
      return dataset; 
    }
    public JFreeChart crearTorta(PieDataset dataset){
         JFreeChart chart = ChartFactory.createPieChart(      
         "Rendimiento",   // chart title 
         dataset,          // data    
         true,             // include legend   
         true, 
         false);
         return chart; 
    }
    
    
}
